const pguser = 'postgres';
const pghost = 'localhost';
const pgdatabase = 'veti';
const pgpassword = 'root';
const pgport = '5432';

const { Pool, Client } = require('pg')
const pool = new Pool({
  user: pguser,
  host: pghost,
  database: pgdatabase,
  password: pgpassword,
  port: pgport,
})

module.exports = pool;
