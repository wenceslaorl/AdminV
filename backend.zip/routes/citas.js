var express = require("express");
const pool = require("../db");
var router = express.Router();

//insertar
router.post("/", async(req,res) => {
    try{
        const {nombre, fecha, raza, especie} = req.body;
        const nuevamasco = await pool.query("insert into citas (nombre, fecha) values ($1, $2) RETURNING *", [nombre, fecha]);
        res.json(nuevamasco.rows[0]);        
    }catch (err) {
        console.error(err.message);

    }
});


//obtener
router.get("/", async(req,res) => {
    try {
        const { rows } = await pool.query("select * from citas ORDER BY id ASC");
        res.json( { Arrayresponse: rows})
    } catch (err) {
        console.error(err.message);
        
    }
});


//obtener para editar
router.get("/:id", async(req, res) => {
    try {
        const { id } = req.params;        
        const rows = await pool.query("select * from citas where id = $1", [id]);
        res.json( rows.rows[0] )              
    } catch (err) {
        console.error(err.message);
    }
});


//editar
router.put("/:id", async(req,res) => {
    try {
        const { id } = req.params;
        const { body } = req.body;            
        const updateTodo = await pool.query("update citas set id = $1, nombre = $2, fecha = $3 where id = $4",[body.id, body.nombre, body.fecha, id]);
        res.json("Todo actualizado");        
    } catch (err) {
        console.error(err.message);
    }
});


//borrar
router.delete("/:id", async(req,res) =>{
    try {
        const { id } = req.params;
        const deleteTodo = await pool.query("delete from citas where id = $1", [id])
        res.json("Eliminado")
    } catch (err) {
        console.error(err.message);        
    }
});


module.exports = router;