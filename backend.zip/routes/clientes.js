var express = require("express");
const pool = require("../db");
var router = express.Router();

//insertar
router.post("/", async(req,res) => {
    try{
        const {nombre, apellido_paterno, apellido_materno, rut, telefono, direccion, email} = req.body;
        const newTodo = await pool.query("insert into clientes (nombre, apellido_paterno, apellido_materno, rut, telefono, direccion, email) values ($1, $2, $3, $4, $5, $6, $7) RETURNING *", [nombre, apellido_paterno, apellido_materno, rut, telefono, direccion, email]);
        res.json(newTodo.rows[0]);
    }catch (err) {
        console.error(err.message);

    }
});


//obtener
router.get("/", async(req,res) => {
    try {
        const { rows } = await pool.query("select * from clientes ORDER BY id ASC");
        res.json( { Arrayresponse: rows})
    } catch (err) {
        console.error(err.message);
        
    }
});


//obtener para editar
router.get("/:id", async(req, res) => {
    try {
        const { id } = req.params;
        const rows = await pool.query("select * from clientes where id = $1", [id]);
        res.json( rows.rows[0] )
    } catch (err) {
        console.error(err.message);
    }
});


//editar
router.put("/:id", async(req,res) => {
    try {
        const { id } = req.params;
        const { body } = req.body;
        const editarcliente = await pool.query("update clientes set id = $1, nombre = $2, apellido_paterno = $3, apellido_materno = $4, rut = $5, telefono = $6, direccion = $7, email = $8 where id = $9",[body.id, body.nombre, body.apellido_paterno, body.apellido_materno, body.rut, body.telefono, body.direccion, body.email, id]);
        res.json("Todo actualizado");        
    } catch (err) {
        console.error(err.message);
    }
});


//borrar
router.delete("/:id", async(req,res) =>{
    try {
        const { id } = req.params;
        const deleteTodo = await pool.query("delete from clientes where id = $1", [id])
        res.json("Eliminado")
    } catch (err) {
        console.error(err.message);        
    }
});


module.exports = router;