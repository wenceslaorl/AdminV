var express = require("express");
const pool = require("../db");
var router = express.Router();

//insertar
router.post("/", async(req,res) => {
    try{
        const {motivo_consulta, tratamiento, prestaciones, fecha_consulta} = req.body;
        const newTodo = await pool.query("insert into consultas (motivo_consulta, tratamiento, prestaciones, fecha_consulta) values ($1, $2, $3, $4) RETURNING *", [motivo_consulta, tratamiento, prestaciones, fecha_consulta]);
        res.json(newTodo.rows[0]);
    }catch (err) {
        console.error(err.message);

    }
});


//obtener
router.get("/", async(req,res) => {
    try {
        const { rows } = await pool.query("select * from consultas ORDER BY id ASC");
        res.json( { Arrayresponse: rows})
    } catch (err) {
        console.error(err.message);
        
    }
});


//obtener para editar
router.get("/:id", async(req, res) => {
    try {
        const { id } = req.params;
        const todo = await pool.query("select * from consultas where id = $1", [id]);
        res.json(todo.rows[0])
    } catch (err) {
        console.error(err.message);
    }
});


//editar
router.put("/:id", async(req,res) => {
    try {
        const { id } = req.params;
        const { body } = req.body;
        const updateTodo = await pool.query("update consultas set id = $1, motivo_consulta = $2, tratamiento = $3, prestaciones = $4, fecha_consulta = $5 where id = $6",[body.id, body.motivo_consulta, body.tratamiento, body.prestaciones, body.fecha_consulta, id]);
        res.json("Todo actualizado");        
    } catch (err) {
        console.error(err.message);
    }
});


//borrar
router.delete("/:id", async(req,res) =>{
    try {
        const { id } = req.params;
        const deleteTodo = await pool.query("delete from consultas where id = $1", [id])
        res.json("Eliminado")
    } catch (err) {
        console.error(err.message);        
    }
});


module.exports = router;