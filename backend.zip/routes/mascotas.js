var express = require("express");
const pool = require("../db");
var router = express.Router();

//insertar
router.post("/", async(req,res) => {
    try{
        const {nombre, fecha, raza, especie} = req.body;
        const nuevamasco = await pool.query("insert into mascotas (nombre, fecha, raza, especie) values ($1, $2, $3, $4) RETURNING *", [nombre, fecha, raza, especie]);
        res.json(nuevamasco.rows[0]);        
    }catch (err) {
        console.error(err.message);

    }
});


//obtener
router.get("/", async(req,res) => {
    try {
        const { rows } = await pool.query("select * from mascotas ORDER BY id ASC");
        res.json( { Arrayresponse: rows})
    } catch (err) {
        console.error(err.message);
        
    }
});


//obtener para editar
router.get("/:id", async(req, res) => {
    try {
        const { id } = req.params;        
        const rows = await pool.query("select * from mascotas where id = $1", [id]);
        res.json( rows.rows[0] )              
    } catch (err) {
        console.error(err.message);
    }
});


//editar
router.put("/:id", async(req,res) => {
    try {
        const { id } = req.params;
        const { body } = req.body;            
        const updateTodo = await pool.query("update mascotas set id = $1, nombre = $2, fecha = $3, raza = $4, especie = $5 where id = $6",[body.id, body.nombre, body.fecha, body.raza, body.especie, id]);
        res.json("Todo actualizado");        
    } catch (err) {
        console.error(err.message);
    }
});


//borrar
router.delete("/:id", async(req,res) =>{
    try {
        const { id } = req.params;
        const deleteTodo = await pool.query("delete from mascotas where id = $1", [id])
        res.json("Eliminado")
    } catch (err) {
        console.error(err.message);        
    }
});


module.exports = router;