var express = require("express");
const pool = require("../db");
var router = express.Router();

router.get("/", async function(req,res,next){
    const  rows  = await pool.query('SELECT * FROM mascotas')
    res.json(rows.rows)

});

router.delete("/:id", async(req,res) =>{
    try {
        const { id } = req.params;
        const rows = await pool.query("delete from mascotas where id = $1", [id])
        res.json({ Arrayresponse: rows})
    } catch (err) {
        console.error(err.message);        
    }
});

module.exports = router;