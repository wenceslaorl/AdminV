import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import './App.css';

import login from "./components/login";
import dashboard from "./components/dashboard";
import mascotas from './components/mascotas';
import clientes from "./components/clientes";
import consultas from "./components/consultas";
import users from "./components/users";
import crearmasco from "./components/crearmasco";
import editamasco from "./components/editamasco";
import crearclien from "./components/crearclien";
import editaclien from "./components/editaclien";
import crearuser from "./components/crearuser";
import editauser from "./components/editauser";
import crearcita from "./components/crearcita";
import editacita from "./components/editacita";
import crearconsulta from "./components/crearconsulta";
import editaconsulta from "./components/editaconsulta";
import testAPI from "./components/testAPI";


function App() {
  return (     
    <BrowserRouter>
    <Switch>    
      <Route exact path={"/"} component={login}/>
      <Route exact path="/dashboard" component={dashboard}/>
      <Route exact path="/mascotas" component={mascotas}/>
      <Route exact path="/clientes" component={clientes}/>
      <Route exact path="/consultas" component={consultas}/>
      <Route exact path="/users" component={users}/>
      <Route exact path="/mascotas/crear" component={crearmasco}/>
      <Route exact path="/mascotas/editar/:id" component={editamasco}/>
      <Route exact path="/clientes/crear" component={crearclien}/>
      <Route exact path="/clientes/editar/:id" component={editaclien}/>
      <Route exact path="/users/crear" component={crearuser}/>
      <Route exact path="/users/editar/:id" component={editauser}/>
      <Route exact path="/crear/citas" component={crearcita}/>
      <Route exact path="/citas/editar/:id" component={editacita}/>
      <Route exact path="/consultas/crear" component={crearconsulta}/>
      <Route exact path="/consultas/editar/:id" component={editaconsulta}/>
      <Route exact path="/testAPI" component={testAPI}/>   
    </Switch>
  </BrowserRouter>          
    
  );
}


export default App;
