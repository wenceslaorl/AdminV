import React, { Component } from 'react';
import request from 'superagent';
import Cookies from 'universal-cookie';
import Swal from 'sweetalert2'

const cookies = new Cookies();

class App extends Component{
  constructor(){
    super();
    this.state = {
      consultas: []
    }
  }

  componentWillMount() {
      request
        .get('http://localhost:9000/consultas')
        .end((err, res) => {
          const consultas = JSON.parse(res.text).Arrayresponse;
          this.setState({
            consultas: consultas
            
          });
        });
    
  }

  borrarconsulta(id) {


    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })
    
    swalWithBootstrapButtons.fire({
      title: '¿Esta seguro?',
      text: "Va a eliminar la consulta #: " + id,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Si, Borrarlo!',
      cancelButtonText: 'No, cancelar!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {     
        request
        .del("http://localhost:9000/consultas/" + id)       
        .end((err, res) => {            
        window.location = "/consultas";
    });
      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire(
          'Cancelado',
          'No se borro el ingreso',
          'error'
        )
      }
    })   
  }

  cerrarSesion=()=>{
    cookies.remove('id', {path: "/"});
    cookies.remove('apellido_paterno', {path: "/"});
    cookies.remove('apellido_materno', {path: "/"});
    cookies.remove('nombre', {path: "/"});
    cookies.remove('usuario', {path: "/"});
    window.location.href='./';
  }


  componentDidMount() {
    if(!cookies.get('usuario')){
        window.location.href="./";
    }    
  }

  Funcionbuscar() {
    // Declare variables
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("textinput");
    filter = input.value.toUpperCase();
    table = document.getElementById("Tabla");
    tr = table.getElementsByTagName("tr");
  
    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  render() {
    var consultas = this.state.consultas.map((consulta) => {
      return (
        <tr>
        <th scope="row">{consulta.id} </th>
        <td>{consulta.motivo_consulta}</td>
        <td>{consulta.tratamiento}</td>
        <td>{consulta.prestaciones}</td>
        <td>{consulta.fecha_consulta}</td>
        <td>
        <button
        className="btn btn-warning btn-sm"        
        onClick={() => window.location = `/consultas/editar/${consulta.id}`}
      >
      Editar
      </button>
         </td>
         <td>
            <button
              className="btn btn-danger btn-sm"        
              onClick={() => this.borrarconsulta(consulta.id)}
            >
            Borrar
            </button>
       </td>
       </tr>      
      )
    });

    return(
      <><header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
      <li class="navbar-brand col-md-3 col-lg-2 me-0 px-3">
        <a class="navbar-brand " href="/dashboard" id="usuariomenulink" role="button" >
        <span data-feather="activity"></span> Mundo Animal <span data-feather="activity"></span>
        </a>     
      </li>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <input class="form-control form-control-dark w-100" type="text" id="textinput" onChange={() => this.Funcionbuscar()} placeholder="Buscar" aria-label="Search"></input>
    <div class="navbar-nav">
    <div class="nav-item text-nowrap">
      <button class="nav-link px-3 btn-dark" onClick={()=>this.cerrarSesion()}>Salir <span data-feather="log-out"></span></button>
    </div>
    </div>
    </header>
    <div class="container-fluid">
    <div class="row">
      <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        <div class="position-sticky pt-3">
          <ul class="nav flex-column">
           
          <div class="accordion-item">
          <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
              <span data-feather="home"></span>            
              &nbsp; Dashboard
            </button>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
            <div class="accordion-body">
            <li class="nav-item">
            <a class="nav-link" aria-current="page" href="/dashboard">
              <span data-feather="calendar"></span>
              &nbsp; Dashboard 
            </a>
          </li>
            </div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingTwo">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
              <span data-feather="user"></span> 
              &nbsp; Clientes
            </button>
          </h2>
          <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
            <div class="accordion-body">
              <li class="nav-item">
                <a class="nav-link" href="/clientes">
                  <span data-feather="list"></span>
                  &nbsp; Listado
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/clientes/crear">
                  <span data-feather="plus-square"></span> 
                  &nbsp; Agregar
                </a>
              </li>
            </div>
          </div>
        </div>
        <div class="accordion-item">
        <h2 class="accordion-header" id="headingThree">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            <span data-feather="github"></span> 
            &nbsp; Mascotas
          </button>
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <li class="nav-item">
              <a class="nav-link" href="/mascotas">
                <span data-feather="list"></span>         
                &nbsp; Listado
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/mascotas/crear">
                <span data-feather="plus-square"></span> 
                &nbsp; Agregar
              </a>
            </li>
          </div>
        </div>
      </div>
      <div class="accordion-item">
      <h2 class="accordion-header" id="headingFour">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          <span data-feather="file-text"></span>  
          &nbsp; Consultas
        </button>
      </h2>
      <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <li class="nav-item">
            <a class="nav-link active" href="/consultas"> 
              <span data-feather="list"></span>       
              &nbsp; Listado
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/consultas/crear">
            <span data-feather="plus-square"></span> 
            &nbsp; Agregar
            </a>
          </li>   
        </div>
      </div>
    </div>
  
    {(() => {
      if (cookies.get('usuario') === 'admin') {
        return (
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingFive">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
              <span data-feather="users"></span>
              &nbsp; Usuarios
            </button>
          </h2>
          <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
            <div class="accordion-body">
              <li class="nav-item">
                <a class="nav-link" href="/users">  
                  <span data-feather="list"></span>          
                  &nbsp; Listado
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href="/users/crear">
                  <span data-feather="plus-square"></span> 
                  &nbsp; Agregar
                </a>
              </li>
            </div>
          </div>
        </div>       
        )          
       } 
    })()}    
          </ul>
          <br></br>
          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Agendar Cita</span>
            <a class="link-secondary" href="/crear/citas" aria-label="Add a new meet">
              <span data-feather="plus-circle"></span>
            </a>
          </h6>
        </div>
      </nav><><main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h2">Consultas</h1>
          <div class="btn-toolbar mb-2 mb-md-0">
            <a class="btn btn-sm btn-success" href="/consultas/crear">
              <span data-feather="plus"></span>
              Crear
            </a>
          </div>
        </div><><br></br><div>
          <h1 class="text-center">Listado</h1>
          <ul>
            <div class="container">
              <div class="table-responsive">
                <table class="table mt-5 text-center" id="Tabla">
                  <thead>
                    <tr>
                      <th>id</th>
                      <th>motivo_consulta</th>
                      <th>tratamiento</th>
                      <th>prestaciones</th>
                      <th>fecha_consulta</th>
                      <th><span data-feather="edit"></span></th>
                      <th><span data-feather="trash-2"></span></th>
                    </tr>
                  </thead>
                  <tbody>
                    {consultas}
                  </tbody>
                </table>
              </div>
            </div>
          </ul>
        </div></></main></></div></div></>

    )
  }
}

export default App;

