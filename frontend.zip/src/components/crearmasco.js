import React, { Fragment, useState } from "react";
import Cookies from 'universal-cookie';
import Swal from 'sweetalert2'
import request from 'superagent';

const cookies = new Cookies();

const Register = () => {
  
  const [inputs, setInputs] = useState({
    nombre: "",
    fecha: "",
    raza: "",
    especie: "",
    clientes: []
  });


  const retornarValores = () => {
    request
      .get('http://localhost:9000/clientes')
      .end((err, res) => {
        const clientes = JSON.parse(res.text).Arrayresponse;
        this.setState({
          clientes: clientes
        });
      });
  }
  // const valor = retornarValores();
  const { nombre, fecha, raza, especie} = inputs;

  const onChange = e =>
    setInputs({ ...inputs, [e.target.name]: e.target.value });

  const onSubmitForm = async e => {
    e.preventDefault();
    try {
      const body = { nombre, fecha, raza, especie};
      const response = await fetch(
        "http://localhost:9000/mascotas",
        {
          method: "POST",
          headers: {
            "Content-type": "application/json"
          },
          body: JSON.stringify(body)
        }
      );
     const parseRes = await response.json();

     if (parseRes) {        
      Swal.fire({
        title: 'Agregado',
        text: "Su nueva mascota fue guardada!",
        icon: 'success',
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'OK!'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location = "/mascotas";
        }
      })
      
    } else { 
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Algo salio mal y no se pudo guardar',
        footer: '<a href="">Contacte al administrador</a>'
      })    
    }
      
    } catch (err) {
      console.error(err.message);
    }
  };

  const cerrarSesion=()=> {
    cookies.remove('id', {path: "/"});
    cookies.remove('apellido_paterno', {path: "/"});
    cookies.remove('apellido_materno', {path: "/"});
    cookies.remove('nombre', {path: "/"});
    cookies.remove('usuario', {path: "/"});
    window.location.href='/';

  }

  // var clientes = this.state.clientes.map((cliente, i=cliente.id) => {
  //   return ( 
  //     <select>
  //       <option value={cliente.id}> {cliente.nombre}</option>
  //     </select>
  //   )
  // });

  return (
    <Fragment> 
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <li class="navbar-brand col-md-3 col-lg-2 me-0 px-3">
      <a class="navbar-brand " href="/dashboard" id="usuariomenulink" role="button" >
      <span data-feather="activity"></span> Mundo Animal <span data-feather="activity"></span>
      </a>     
    </li>
  <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button> 
  <div class="navbar-nav">
  <div class="nav-item text-nowrap">
    <button class="nav-link px-3 btn-dark" onClick={()=>cerrarSesion()}>Salir <span data-feather="log-out"></span></button>
  </div>
  </div>
  </header>
  <div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
      <ul class="nav flex-column">
      <div class="accordion-item">
      <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
          <span data-feather="home"></span>            
          &nbsp; Dashboard
        </button>
      </h2>
      <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
        <div class="accordion-body">
        <li class="nav-item">
        <a class="nav-link" aria-current="page" href="/dashboard">
          <span data-feather="calendar"></span>
          &nbsp; Dashboard 
        </a>
      </li>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          <span data-feather="user"></span> 
          &nbsp; Clientes
        </button>
      </h2>
      <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <li class="nav-item">
            <a class="nav-link" href="/clientes">
              <span data-feather="list"></span>
              &nbsp; Listado
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/clientes/crear">
              <span data-feather="plus-square"></span> 
              &nbsp; Agregar
            </a>
          </li>
        </div>
      </div>
    </div>
    <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        <span data-feather="github"></span> 
        &nbsp; Mascotas
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <li class="nav-item">
          <a class="nav-link" href="/mascotas">
            <span data-feather="list"></span>         
            &nbsp; Listado
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="/mascotas/crear">
            <span data-feather="plus-square"></span> 
            &nbsp; Agregar
          </a>
        </li>
      </div>
    </div>
  </div>
  <div class="accordion-item">
  <h2 class="accordion-header" id="headingFour">
    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
      <span data-feather="file-text"></span>  
      &nbsp; Consultas
    </button>
  </h2>
  <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
    <div class="accordion-body">
      <li class="nav-item">
        <a class="nav-link" href="/consultas"> 
          <span data-feather="list"></span>       
          &nbsp; Listado
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/consultas/crear">
        <span data-feather="plus-square"></span> 
        &nbsp; Agregar
        </a>
      </li>   
    </div>
  </div>
</div>

{(() => {
  if (cookies.get('usuario') === 'admin') {
    return (
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingFive">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
          <span data-feather="users"></span>
          &nbsp; Usuarios
        </button>
      </h2>
      <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <li class="nav-item">
            <a class="nav-link" href="/users">  
              <span data-feather="list"></span>          
              &nbsp; Listado
            </a>
          </li> 
          <li class="nav-item">
            <a class="nav-link" href="/users/crear">
              <span data-feather="plus-square"></span> 
              &nbsp; Agregar
            </a>
          </li>
        </div>
      </div>
    </div>       
    )          
   } 
})()}    
      </ul>
      <br></br>
      <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
        <span>Agendar Cita</span>
        <a class="link-secondary" href="/crear/citas" aria-label="Add a new meet">
          <span data-feather="plus-circle"></span>
        </a>
      </h6>     
    </div>
  </nav>   
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">   
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">Crear Mascota</h1>
      <div class="btn-toolbar mb-2 mb-md-0">          
        <a  class="btn btn-sm btn-dark" href="/mascotas">                              
          <span data-feather="arrow-left"></span>
          Ir a mascotas
        </a>
      </div>
    </div> 
    <div class="container">   
    <br></br>
      <form onSubmit={onSubmitForm}>
        <input
          type="text"
          name="nombre"
          value={nombre}
          placeholder="nombre"
          onChange={e => onChange(e)}
          className="form-control my-3 col-md-4"
        />
        <input
          type="date"
          name="fecha"
          value={fecha}
          placeholder="fecha de nacimiento"
          onChange={e => onChange(e)}
          className="form-control my-3 col-md-4"
        />
        <input
          type="text"
          name="raza"
          value={raza}
          placeholder="raza"
          onChange={e => onChange(e)}
          className="form-control my-3 col-md-4"
        />
        <input
        type="text"
        name="especie"
        value={especie}
        placeholder="especie"
        onChange={e => onChange(e)}
        className="form-control my-3 col-md-4"
        />
        <select className="form-control my-3 col-md-4">
          <option>Seleccione un cliente</option>
          <option>juan</option>
          <option>bla</option>
          <option>juana</option>
          <option>maria</option>

        </select>
        <button className="btn btn-success btn-block col-md-4" type="submit">Crear</button>
      </form> 
    </div>  
    </main>   
    </div>
    </div>
    </Fragment>
  );
};

export default Register;


