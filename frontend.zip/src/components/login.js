import React, { Component } from 'react';
//import '../css/Login.css';
import axios from 'axios';
//import md5 from 'md5';
import Cookies from 'universal-cookie';
import './style.css';


const baseUrl="http://localhost:9000/users/log";
const cookies = new Cookies();

class Login extends Component {
    state={
        form:{
            usuario: '',
            clave: ''
        }
    }

    handleChange=async e=>{
        await this.setState({
            form:{
                ...this.state.form,
                [e.target.name]: e.target.value
            }
        });
    }

    iniciarSesion=async()=>{
        await axios.get(baseUrl, {params: {usuario: this.state.form.usuario, clave: this.state.form.clave}})
        .then(response=>{
            //console.log(response);
            return response.data;
           
        })
        .then(response=>{
            if(response.length>0){                
                var respuesta=response[0];
                cookies.set('id', respuesta.id, {path: "/"});
                cookies.set('nombre', respuesta.nombre, {path: "/"});
                cookies.set('apellido_paterno', respuesta.apellido_paterno, {path: "/"});
                cookies.set('apellido_materno', respuesta.apellido_materno, {path: "/"});
                cookies.set('usuario', respuesta.usuario, {path: "/"});
                alert(`Bienvenido ${respuesta.nombre} ${respuesta.apellido_paterno}`);
                window.location.href="./dashboard";
            }else{
                alert('El usuario o la contraseña no son correctos');
            }
        })
        .catch(error=>{
            console.log(error);
        })

    }

    componentDidMount() {        
        if(cookies.get('usuario')){
            window.location.href="./dashboard";
        }
    }
    
    render() {
        return (
            <>  
            <div className='divv'>
                <div className="modal modal-signin position-static d-block py-5 " tabindex="-1" role="dialog" id="modalSignin">
                    <div className="modal-dialog " role="document">
                        <div className="modal-content rounded-5 shadow">
                            <div className="modal-header p-0 pb-0 border-bottom-0 imagenStyle">
                                <img src={`${process.env.PUBLIC_URL}/imagenes/logom.png`} alt="logo" /> 
                            </div>
                            <div className="modal-body p-5 pt-0">
                                <div className="form-group">
                                <label>Usuario: </label>
                                <br />
                                <input
                                    type="text"
                                    className="form-control"
                                    name="usuario"
                                    onChange={this.handleChange} />
                                <br />
                                <label>Contraseña: </label>
                                <br />
                                <input
                                    type="password"
                                    className="form-control"
                                    name="clave"
                                    onChange={this.handleChange} />
                                <br />                          
                                    <button className="w-100 mb-2 btn btn-lg rounded-4 btn-primary" onClick={() => this.iniciarSesion()} >Iniciar Sesión</button>
                                    <small className="text-muted">Su usuario debe estar habilitado para poder ingresar.</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </>
   
        );
    }
}

export default Login;