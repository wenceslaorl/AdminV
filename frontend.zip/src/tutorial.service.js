import http from "./http-common";

class TutorialDataService {
  getAll() {
    return http.get("/testAPI");
  }

  get(id) {
    return http.get(`/testAPI/${id}`);
  }

  create(data) {
    return http.post("/testAPI", data);
  }

  update(id, data) {
    return http.put(`/testAPI/${id}`, data);
  }

  delete(id) {
    return http.delete(`/testAPI/${id}`);
  }

  deleteAll() {
    return http.delete(`/testAPI`);
  }

  findByTitle(title) {
    return http.get(`/tutorials?title=${title}`);
  }
}

export default new TutorialDataService();